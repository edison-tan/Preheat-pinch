import pandas as pd
import datetime as DT
from win32com.client.dynamic import Dispatch


class PiServer(object):
    
    def __init__(self, pi_server):
        self.pi_srv = Dispatch('PISDK.PISDK').Servers(pi_server)
        self.pi_time = Dispatch('PITimeServer.PITime')
        self.pi_timeintervals = Dispatch('PITimeServer.TimeIntervals')
        self.pi_timeformat = Dispatch('PITimeServer.PITimeFormat')            

    
    def get_data(self, tag_name, t_start, t_end, t_interval, Timeweighted):
        """Retrieve interpolated data from the PI-server
        
        Args:
            tag_name (str): PI tag name
            t_start (str): PI time format (ex. '*-72h')
            t_end (str): PI time format (ex. '*')
            t_interval (str): PI time format (ex. '1h')
            
        Returns:
            pandas dataframe: index=datetime, col_1=interpolated values
        """
        ##as_Average = Dispatch('PISDK.PISDK').ArchiveSummariesTypeConstants.["asAverage"]
        #as_Average = Dispatch('PISDK.PISDK').PIConstants["ArchiveSummariesTypeConstants"]["Average"].Value
        #asTimeWeighted = Dispatch('PISDK.PISDK').PIConstants["CalculationBasisConstants"]["cbTimeWeighted"].Value

        tag = self.pi_srv.PIPoints(tag_name)
        if Timeweighted == True:
            pi_values_buf = tag.Data.Summaries2(t_start, t_end, t_interval,5,0,asynchStatus=None)
            pi_values = pi_values_buf("Average").Value
        else:
        #pi_values = tag.Data.RecordedValues(t_start, t_end,asynchStatus=None)
        #pi_values = tag.Data.PlotValues(t_start, t_end, 4321,asynchStatus=None)
            pi_values = tag.Data.InterpolatedValues2(t_start, t_end, t_interval, asynchStatus=None)
        
        
        return (self.pivalues_to_df(pi_values, tag_name))
    
    def get_data_multiple(self, tags, t_start, t_end, t_interval, Timeweighted, progress, i):
        """Retrieve interpolated data from the PI-server for multiple tags
        
        Args:
            tags (list): List of PI tag names
            t_start (str): PI time format (ex. '*-72h')
            t_end (str): PI time format (ex. '*')
            t_interval (str): PI time format (ex. '1h')
            
        Returns:
            pandas dataframe: index=datetime, cols=interpolated values
        
        """
        list_of_values = []
        CountTag=0
        TotTag=len(tags)
        for tag in tags:
            df = self.get_data(tag, t_start, t_end, t_interval,Timeweighted)
            
            # drop duplicated indices -> result of summer-to-winter time 
            # transition. Not doing this results in the subsequent join() to 
            # spiral out of control
            df = df[~df.index.duplicated()]
            list_of_values.append(df)
            CountTag=CountTag+1
            print("Completed " +  str((((CountTag/TotTag)*progress/(i+1))+ progress*(i/(i+1)))*100) + " %", end ='\r')
            
        df_values = pd.DataFrame().join(list_of_values, how='outer')
        
        return df_values


    def pivalues_to_df(self, pivalues, col_name = 'value'):
        """Converts a list of PI-value objects to a pandas dataframe
        
        Args:
            pivalues (list): List of PI-value objects
            col_name (str): desired name of the pandas df column
            
        Returns:
            pandas dataframe: index=datetime, column=list_of_values
        """
        list_of_values = []
        list_of_datetimes = []
        for v in pivalues:
            try:
                list_of_values.append(v.Value)
                list_of_datetimes.append(self.epoch_to_dt(v.TimeStamp))
            except:
                pass
        df = pd.DataFrame({'date':list_of_datetimes, col_name: list_of_values})
        df = df.set_index('date')

        return df

    def timeformat(self, arg):
        """Converts a relative time str to a PI datetime formatted string
        
        Args:
            arg (str): relative time string i.e. '*' or '*-24h'
            
        Returns:
            str: formatted datetime i.e. '17-10-2017 9:48:15'
        
        """
        try:
            self.pi_timeformat.InputString = arg
            return self.pi_timeformat.OutputString
        except:
            logger.error('`%s` is an invalid PI time format' % arg)
            return arg

    def epoch_to_dt(self, timestamp):
        """Convert epoch to human readable date and vice versa
        
        Args:
            timestamp (float): Unix epoch timestamp i.e. '1508227058.0'
            
        Returns:
            (datetime object)
        """
        return DT.datetime.fromtimestamp(int(timestamp))
    
    def PItoDF(self, tags, StartTime, EndTime, Interval, Timeweighted, Batchsize):
        """Convert PI data into dataframe
        Args:
            tags (list): List of PI tag names
            StartTime (str): PI time format (ex. '%d/%m/%Y %H:%M %p')
            EndTime (str): PI time format (ex. '%d/%m/%Y %H:%M %p')
            Interval (str): PI time format (ex. '1m/1h/1d')
            Timeweighted (bin): 0 when pulling interpolated data, 1 when pulling time-weighted
            Batchsize (int): size of pulling pi data in batches in dayS
            
        Returns:
            pandas dataframe: index=datetime, cols=interpolated values
            
        """
        
        df= pd.DataFrame()
        DTFormatString = "%Y-%m-%d %H:%M:%S" 
        #Calculate query interval
        StartTime_DT = DT.datetime.strptime(StartTime,"%d/%m/%Y %H:%M %p")
        EndTime_DT = DT.datetime.strptime(EndTime,"%d/%m/%Y %H:%M %p")
        QueryInterval = EndTime_DT - StartTime_DT
        
        for i in range(QueryInterval.days//Batchsize):
        #pull data in batchesize to prevent Timeout error
            #add batchsize to starttime_dt every cycle
            StartTime = StartTime_DT.strftime(DTFormatString)
            StartTime_DT += DT.timedelta(days = Batchsize)
            EndTime = StartTime_DT.strftime(DTFormatString)
            
            progress = (i+1) * Batchsize/QueryInterval.days

            df1 = self.get_data_multiple(tags, StartTime, EndTime, Interval,Timeweighted, progress, i)
            df1["date"]=list(df1.index.strftime("%d/%m/%Y %h:%M:%s"))

            if Timeweighted == True:
                df = pd.concat([df,df1])
            else:
                df = pd.concat([df,df1[:-1]])
         ### handle remaining days outside of batch
        if QueryInterval.days%Batchsize != 0:
            StartTime = StartTime_DT.strftime(DTFormatString)
            StartTime_DT += DT.timedelta(days=QueryInterval.days%Batchsize)
            EndTime = StartTime_DT.strftime(DTFormatString)
            
            i = QueryInterval.days/Batchsize - 1
            progress = 1
            
            df1 = self.get_data_multiple(tags, StartTime, EndTime, Interval,Timeweighted, progress, i)
            df1["date"]=list(df1.index.strftime("%d/%m/%Y %h:%M:%s"))
            if Timeweighted == True:
                df = pd.concat([df,df1])
            else:
                df = pd.concat([df,df1[:-1]])
                
        return df